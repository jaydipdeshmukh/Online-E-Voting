<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='Log&adm.css'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <!-- JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    
</head>
<body>
    <!-- navbar - start -->

    <header class="bg-white">
        <nav class="flex justify-between items-center w-[92%]  mx-auto">
            <div>
                <img class="w-16 cursor-pointer" src="./Images/logo.jpg" alt="...">
            </div>
            <div
                class="nav-links duration-500 md:static absolute bg-white md:min-h-fit min-h-[60vh] left-0 top-[-100%] md:w-auto  w-full flex items-center px-5">
                <ul class="flex md:flex-row flex-col md:items-center md:gap-[4vw] gap-8">
                    <li>
                        <a class="hover:text-gray-500" href="Login.php">Voter</a>
                    </li>
                    <li>
                        <a class="hover:text-gray-500" href="NomineeRegister.php">Candidate</a>
                    </li>
                    <li>
                        <a class="hover:text-gray-500" href="about.html">About</a>
                    </li>
                    <li>
                        <a class="hover:text-gray-500" href="#help">Steps</a>
                    </li>
                    <li>
                        <a class="hover:text-gray-500" href="Result_Index.php">Result</a>
                    </li>
                </ul>
            </div>
            <div class="flex items-center gap-6">
                <a href="admin.php">
                    <button class="bg-[#000] text-white px-5 py-2 rounded-full hover:bg-[#8692f7]">Admin</button>
                </a>
                <ion-icon onclick="onToggleMenu(this)" name="menu" class="text-3xl cursor-pointer md:hidden"></ion-icon>
            </div>
    </header>

    <script>
        const navLinks = document.querySelector('.nav-links')
        function onToggleMenu(e){
            e.name = e.name === 'menu' ? 'close' : 'menu'
            navLinks.classList.toggle('top-[9%]')
        }
    </script>

    <!-- navbar - end-->

    <div class="login">
        <h1>Login</h1>
        <form action="" method="POST">
            <div class="txt_field">
                <input type="email" name="Email" required placeholder="Enter E-mail">
            </div>
            <div class="txt_field">
                <input type="date" name="DOB" required>
            </div>
            <div class="txt_field">
                <input type="password" name="Password" required placeholder="Enter Pasword">
            </div><br>
            <input type="submit" name="submit" value="Login">
            <div class="signup_link">
                Not yet Register? <a href="Register.php">Register</a>
            </div>
        </form> 
    </div>

    <button class="open-button" onclick="back()">Back</button>

<script>
    function back(){
        window.location="index.html";
    }
</script>  

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "voting_system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if(isset($_POST['submit'])){
     $Email=$_POST['Email'];
     $DOB=$_POST['DOB'];
     $Password=$_POST['Password'];
    
    $select="select * from register where Email='$Email' and Password='$Password'and DOB='$DOB'";
    $run=mysqli_query($conn,$select);
    
      $row_user=mysqli_fetch_array($run);
   
      if(is_array($row_user)){
          $_SESSION['Email']=$row_user['Email'];
          $_SESSION['Voted']=$row_user['Voted'];
          echo "<script> window.open('LoginSuccess.php','_self') </script>";
      }else{
          echo "<h5 style='color:red;text-align:center;'>Wrong Username or Password</h5>".mysqli_error($conn);
      }
      
}
?>

</body>
</html>