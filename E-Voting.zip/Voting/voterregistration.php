<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <!-- importing font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
  <!-- importing tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- stylesheet -->
  <style>
    .registration-box {
      position: absolute;
      width: 400px;
      height: 700px;
      background: #000;
      border-radius: 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      top: 71%;
      left: 50%;
      bottom: 20%;
      transform: translate(-50%, -50%);
    }

    .registration-box h2 {
      color: white;
      font-size: 30px;
      text-align: center;
    }

    .registration-box span {
      position: absolute;
      right: 10px;
      width: 30px;
      height: 30px;
      background-attachment: fixed;
      top: 10px;
      color: white;
      line-height: 30px;
      background-color: #837acd;
      text-align: center;
      border-radius: 20px;
    }

    .input-box {
      position: relative;
      width: 310px;
      margin: 30px 0;
      border-bottom: 2px solid #fff;
    }

    .input-box label {
      position: absolute;
      top: 50%;
      left: 5px;
      transform: translateY(-50%);
      font-size: 1em;
      color: #fff;
      pointer-events: none;
      transform: .5s;
    }

    .input-box input:focus~label,
    .input-box input:valid~label {
      top: -5px;
    }

    .input-box input {
      width: 100%;
      height: 50px;
      background: transparent;
      border: none;
      outline: none;
      font-size: 1em;
      color: #fff;
      padding: 0 35px 0 5px;
    }

    .msg-btn button {
      width: 100%;
      height: 40px;
      background: #837acd;
      border: none;
      outline: none;
      border-radius: 40px;
      cursor: pointer;
      font-size: 1em;
      color: #000;
      font-weight: 500;
    }

    .register-link {
      font-size: .9em;
      color: #fff;
      text-align: center;
      margin: 25px 0 10px;
    }

    .register-link p a {
      color: #fff;
      text-decoration: none;
      font-weight: 600;
    }

    .register-link p a:hover {
      text-decoration: underline;
      color: blue;
    }
  </style>
</head>

<body class="font-[Poppins] h-screen">
  <!-- navbar - start -->
  <header class="bg-white">
    <nav class="flex justify-between items-center w-[92%]  mx-auto">
      <a class="flex title-font font-medium items-center md:justify-start justify-center text-black">
        <img class="w-16 cursor-pointer" src="./assets/logo.png" alt="...">
        <span class="ml-3 text-2xl font-bold">Voting Buddy</span>
      </a>
      <div class="nav-links duration-500 md:static absolute bg-white md:min-h-fit min-h-[60vh] left-0 top-[-100%] md:w-auto  w-full flex items-center px-5">
        <ul class="flex md:flex-row flex-col md:items-center md:gap-[4vw] gap-8 text-1xl">
          <li>
            <a class="hover:text-green-500 font-semibold" href="#">Home</a>
          </li>
          <li>
            <a class="hover:text-green-500 font-semibold" href="#">Voter</a>
          </li>
          <li>
            <a class="hover:text-green-500 font-semibold" href="#">Candidate</a>
          </li>
          <li>
            <a class="hover:text-green-500 font-semibold" href="#">Result</a>
          </li>
        </ul>
      </div>
      <div class="flex items-center gap-6">
        <a href="./admin/adminindex.html">
          <button class="bg-[#837acd] text-black px-5 py-2 rounded-full hover:text-white font-semibold ">Admin</button>
          <ion-icon onclick="onToggleMenu(this)" name="menu" class="text-3xl cursor-pointer md:hidden"></ion-icon>
        </a>
      </div>
  </header>
  <script>
    const navLinks = document.querySelector('.nav-links')

    function onToggleMenu(e) {
      e.name = e.name === 'menu' ? 'close' : 'menu'
      navLinks.classList.toggle('top-[9%]')
    }
  </script>
  <!-- navbar - end -->

  <!-- form - start -->
  <div class="container mx-auto flex px-7 py-80 md:flex-row flex-col items-center border-t">
    <div class="registration-box">
      <form action="" method="post">
        <h2><b>Registration</b></h2>
        <span onclick="back()">&times;</span>
        <div class="input-box">
          <input type="text" name="FullName" required>
          <label>Full Name</label>
        </div>
        <div class="input-box">
          <input type="tel" name="MobileNo" required pattern="[1-9]{1}[0-9]{9}">
          <label>Mobile No</label>
        </div>
        <div class="input-box">
          <input type="email" name="Email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
          <label>Email</label>
        </div>
        <div class="input-box">
          <input type="date" name="DOB" required>
        </div>
        <div class="input-box">
          <input type="password" name="Password" required>
          <label>Password</label>
        </div>
        <div class="input-box">
          <input type="password" name="RePassword" required>
          <label>Re-Enter Password</label>
        </div>
        <div class="msg-btn">
          <button type="submit" name="submit">Submit</button>
        </div>
        <div class="register-link">
          <p>Already have an account?<a href="./voterlogin.php"> Login</a></p>
        </div>
      </form>
    </div>
  </div>
  <script>
    function back() {
      window.location = "index.html";
    }
  </script>

  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "voting_system";

  // Create connection
  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if (isset($_POST['submit'])) {
    $FullName = $_POST['FullName'];
    $MobileNo = $_POST['MobileNo'];
    $Email = $_POST['Email'];
    $DOB = $_POST['DOB'];
    $Password = $_POST['Password'];
    $RePassword = $_POST['RePassword'];
    if ($Password == $RePassword) {

      $insert = "insert into register(FullName,MobileNo,Email,DOB,Password,Status,Voted) values('$FullName','$MobileNo','$Email','$DOB','$Password','OFF','NO')";

      $run_insert = mysqli_query($conn, $insert);
      if ($run_insert === true) {
        echo "<H5 style='color:green;text-align:center;'>Successfully Inseted</h5>";
      } else {
        echo "<H5 style='color:red;text-align:center;'>Not Inseted</h5>" . mysqli_error($conn);
      }
    } else {
      echo "<H5 style='color:red;text-align:center;'>Password is not Matched with RE-Entered Password</h5>";
    }
  }

  ?>

  <!-- form end -->
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <!-- footer - start -->
  <footer class="text-gray-600 body-font py-20 px-5">
    <div class="container mx-auto border-t">
      <div class="flex flex-wrap md:text-center text-center order-first ">
        <div class="lg:w-1/4 md:w-1/2 w-full px-4 ">
          <h2 class="title-font font-bold text-black tracking-widest text-1xl mb-3">MY ACCOUNT</h2>
          <nav class="list-none mb-10">
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold">About us</a>
            </li>
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold">Login</a>
            </li>

          </nav>
        </div>
        <div class="lg:w-1/4 md:w-1/2 w-full px-4">
          <h2 class="title-font font-bold text-black tracking-widest text-1xl mb-3">LEGAL</h2>
          <nav class="list-none mb-10">
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold">Terms of service</a>
            </li>
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold">Privacy Policy</a>
            </li>

          </nav>
        </div>
        <div class="lg:w-1/4 md:w-1/2 w-full px-4">
          <h2 class="title-font font-bold text-black tracking-widest text-1xl mb-3">ABOUT</h2>
          <nav class="list-none mb-10">
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold">Team</a>
            </li>
            <li>
              <a class="text-black hover:text-green-500 cursor-pointer font-semibold" href="./contact.php">Contact</a>
            </li>
          </nav>
        </div>
        <div class="lg:w-1/4 md:w-1/2 w-full px-4 gap-10">
          <h2 class="title-font font-bold text-black tracking-widest text-1xl mb-3">Follow Us On</h2>
          <div class="flex gap-4 justify-center">
            <a href="https://instagram.com/votingbuddy?igshid=YmMyMTA2M2Y=" target="_blank" class="text-black-400 transition duration-100 active:text-gray-600">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="currentColor" style="color: #c13584" viewBox="0 0 28 28">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>

            <a href="#" target="_blank" class="text-gray-400 transition duration-100 active:text-gray-600">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="currentColor" style="color: #1da1f2" viewBox="0 0 28 28">
                <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
              </svg>
            </a>

            <a href="#" target="_blank" class="text-gray-400 transition duration-100 active:text-gray-600">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="currentColor" style="color: #1877f2" viewBox="0 0 28 28">
                <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
              </svg>
            </a>

            <a href="#" target="_blank" class="text-gray-400 transition duration-100 active:text-gray-600">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="currentColor" style="color: #0077b5" viewBox="0 0 28 28">
                <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <div>
    <div class="container px-3 py-3 mx-auto flex items-center sm:flex-row flex-col border-t md:justify-center justify-center">
      <a class="flex title-font font-medium items-center md:justify-center justify-center text-black">
        <img class="w-16 cursor-pointer" src="./assets/logo.png" alt="...">
        <span class="ml-3 text-xl">Voting Buddy</span>
      </a>
      <p class="text-sm text-black sm:ml-6 sm:mt-0 mt-4">©2023 VotingBuddy —
        <a href="http://www.gpk.edu.in/" rel="noopener noreferrer" class="text-black ml-1 hover:text-green-500" target="_blank">@Government Polytechnic Khamgaon</a>
      </p>
    </div>
  </div>
  <!-- footer - end -->
</body>

</html>